<?php
  date_default_timezone_set('America/Costa_Rica');

  $fechaActual = date("d-m-Y");
  $horaActual = date("h:i:s");

  echo "La fecha es: $fechaActual y la hora es $horaActual " ;
?>